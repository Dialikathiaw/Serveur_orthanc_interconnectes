<?php
session_start();
$conn = mysqli_connect("localhost", "user_orthanc", "passer123", "orthanc_app");
if (!$conn) {
    die("Erreur de connexion : " . mysqli_connect_error());
}

// Vérifie si le médecin est connecté
$id_medecin = $_SESSION['id'] ?? null;

// Requête patients + nom hôpital
$query = "SELECT p.*, h.nom AS hopital_nom, h.region, h.adresse FROM patients p LEFT JOIN hopitaux h ON p.hopital_id = h.id_hopital";

$result_patients = mysqli_query($conn, $query);
?>
<!doctype html>
<html class="no-js" lang="fr">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Gestion des Patients - MediPlus</title>
    <link rel="icon" href="img/favicon.png">
    <link href="https://fonts.googleapis.com/css?family=Poppins:200i,300,400,500,600,700,800,900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../Medecin/css/bootstrap.min.css">
    <link rel="stylesheet" href="../Medecin/css/font-awesome.min.css">
    <link rel="stylesheet" href="../Medecin/css/icofont.css">
    <link rel="stylesheet" href="../Medecin/style.css">
    <style>
        .form-section {
            background: #f9f9f9;
            padding: 20px;
            border-radius: 8px;
            margin-top: 30px;
            display: none;
        }
        .add-btn {
            float: right;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>

<!-- Header -->
<header class="header">
    <div class="topbar">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-5 col-12">
                    <ul class="top-link">
                        <li><a href="index.html">Accueil</a></li>
                        <li><a href="contact.html">Contact</a></li>
                        <li><a href="#">À propos</a></li>
                        <li><a href="#">FAQ</a></li>
                    </ul>
                </div>
                <div class="col-lg-6 col-md-7 col-12">
                    <ul class="top-contact">
                        <li><i class="fa fa-phone"></i> +221 33 123 45 67</li>
                        <li><i class="fa fa-envelope"></i> <a href="mailto:support@plateforme-medicale.sn">support@plateforme-medicale.sn</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <div class="header-inner">
        <div class="container">
            <div class="inner">
                <div class="row">
                    <div class="col-lg-3 col-md-3 col-12">
                        <div class="logo">
                            <a href="#"><img src="../Medecin/img/logo.png" alt="Plateforme Médicale"></a>
                        </div>
                        <div class="mobile-nav"></div>
                    </div>
                    <div class="col-lg-7 col-md-9 col-12">
                        <div class="main-menu">
                            <nav class="navigation">
                                <ul class="nav menu">
                                    <li><a href="index.html">Accueil</a></li>
                                    <li><a href="orthanc.html">Serveurs Orthanc</a></li>
                                    <li><a href="fichiers.html">Fichiers Non DICOM</a></li>
                                    <li class="active"><a href="patients.php">Gestion des patients</a></li>
                                    <li><a href="dashboard.html">Tableau de Bord</a></li>
                                    <li><a href="statistiques.html">Statistiques</a></li>
                                    <li><a href="contact.html">Contact</a></li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                    <div class="col-lg-2 col-12">
                        <div class="get-quote">
                            <a href="dashboard.html" class="btn">Accéder</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>

<!-- Bannière -->
<section class="page-banner" style="background: url('../Medecin/img/slider2.jpg') no-repeat center center/cover; height: 85vh; display: flex; align-items: center;">
    <div class="container">
        <div class="text-center text-white">
            <h1 style="color: blue">Gestion des patients</h1>
            <p style="font-size: 20px; color: blue;">Ajouter un patient avec son hôpital</p>
        </div>
    </div>
</section>

<!-- Section principale -->
<!-- Bouton d'ouverture du modal -->
<div class="container mt-5">
    <h2 style="text-align:center;">Patients enregistrés</h2>
    <div class="d-flex justify-content-end mb-3">
    <button class="btn btn-primary" data-toggle="modal" data-target="#modalAjoutPatient">+ Ajouter</button>
</div>


    <?php if (isset($_GET['success'])) : ?>
        <div class="alert alert-success mt-3">Patient et hôpital ajoutés avec succès.</div>
    <?php endif; ?>

    <!-- Tableau des patients -->
    <table class="table table-bordered mt-4">
        <thead class="thead-dark">
            <tr>
                <th>Nom</th>
                <th>Prénom</th>
                <th>Sexe</th>
                <th>Date de naissance</th>
                <th>ID Orthanc</th>
                <th>Hôpital</th>
                <th>Région</th>
                <th>Adresse</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = mysqli_fetch_assoc($result_patients)) : ?>
                <tr>
                    <td><?= htmlspecialchars($row['nom']) ?></td>
                    <td><?= htmlspecialchars($row['prenom']) ?></td>
                    <td><?= htmlspecialchars($row['sexe']) ?></td>
                    <td><?= htmlspecialchars($row['date_naissance']) ?></td>
                    <td><?= htmlspecialchars($row['identifiant_orthanc']) ?></td>
                    <td><?= htmlspecialchars($row['hopital_nom']) ?></td>
                    <td><?= htmlspecialchars($row['region']) ?></td>
                    <td><?= htmlspecialchars($row['adresse']) ?></td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

<!-- Modal -->
<div class="modal fade" id="modalAjoutPatient" tabindex="-1" role="dialog" aria-labelledby="modalAjoutPatientLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="modalAjoutPatientLabel">Ajouter un patient</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="ajouter_patients.php" method="POST">
            <!-- Infos patient -->
            <div class="form-group">
                <label>Nom :</label>
                <input type="text" name="nom" class="form-control" required>
            </div>
            <div class="form-group">
                <label>Prénom :</label>
                <input type="text" name="prenom" class="form-control" required>
            </div>
            <div class="form-group">
                <label>Sexe :</label>
                <select name="sexe" class="form-control" required>
                    <option value="Homme">Homme</option>
                    <option value="Femme">Femme</option>
                </select>
            </div>
            <div class="form-group">
                <label>Date de naissance :</label>
                <input type="date" name="date_naissance" class="form-control" required>
            </div>
            <div class="form-group">
                <label>Identifiant Orthanc :</label>
                <input type="text" name="identifiant_orthanc" class="form-control" required>
            </div>

            <!-- Infos hôpital -->
            <h5 class="mt-4">Informations de l'hôpital</h5>
            <div class="form-group">
                <label>Nom de l’hôpital :</label>
                <input type="text" name="hopital_nom" class="form-control" required>
            </div>
            <div class="form-group">
                <label>Région :</label>
                <input type="text" name="hopital_region" class="form-control">
            </div>
            <div class="form-group">
                <label>Adresse :</label>
                <textarea name="hopital_adresse" class="form-control"></textarea>
            </div>

            <input type="hidden" name="id_medecin" value="<?= htmlspecialchars($id_medecin) ?>">
            <button type="submit" class="btn btn-success">Ajouter</button>
        </form>
      </div>
    </div>
  </div>
</div>

<script src="../Medecin/js/jquery.min.js"></script>
<script src="../Medecin/js/bootstrap.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
